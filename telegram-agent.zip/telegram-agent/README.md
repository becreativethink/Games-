# 🤖 Telegram AI Agent

An autonomous AI agent that lives entirely inside Telegram — no website, no dashboard, no complexity.  
Users connect their services, type a task, and the AI executes it automatically.

---

## ✨ Features

| Feature | Details |
|---|---|
| 🧠 Default AI | Qwen 2.5 7B via Hugging Face (free, 4 msg limit) |
| 🔑 Custom AI | OpenAI · Gemini · Claude · OpenRouter |
| 📧 Gmail | Read, summarise, search emails |
| 📁 Google Drive | List, search, browse files |
| 🐙 GitHub | Repos, issues, PRs, starred, gists |
| 🔒 Security | AES-128 Fernet encryption on all API keys |
| ☁️ Storage | Firebase Realtime Database |
| 🔄 Live Config | Update HF API key via Firebase — no redeploy |

---

## 🚀 Quick Start

### 1. Clone & Install

```bash
git clone <your-repo>
cd telegram-agent
pip install -r requirements.txt
```

### 2. Configure (optional)

Credentials are already hardcoded in `config.py`. To override, create `.env`:

```bash
cp .env.example .env
# Edit .env with your values (optional)
```

### 3. Initialise Firebase

```bash
python setup_firebase.py
```

This writes your HF API key to Firebase so you can update it without redeploying.

### 4. Run

```bash
python bot.py
```

---

## 🌐 Deployment

### Option A — VPS / Server (Recommended)

```bash
# Install Python 3.11+
sudo apt update && sudo apt install python3.11 python3-pip -y

# Clone and install
git clone <repo>
cd telegram-agent
pip3 install -r requirements.txt

# Run in background with screen
screen -S telegram-agent
python3 bot.py
# Ctrl+A, D to detach
```

### Option B — Systemd Service (Production)

```bash
sudo nano /etc/systemd/system/telegram-agent.service
```

```ini
[Unit]
Description=Telegram AI Agent Bot
After=network.target

[Service]
Type=simple
User=ubuntu
WorkingDirectory=/home/ubuntu/telegram-agent
ExecStart=/usr/bin/python3 bot.py
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
```

```bash
sudo systemctl daemon-reload
sudo systemctl enable telegram-agent
sudo systemctl start telegram-agent
sudo systemctl status telegram-agent
```

### Option C — Railway / Render (Cloud, Free Tier)

1. Push code to GitHub
2. Create new project on [Railway.app](https://railway.app) or [Render.com](https://render.com)
3. Connect GitHub repo
4. Set start command: `python bot.py`
5. Deploy!

### Option D — Docker

```dockerfile
FROM python:3.11-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt
COPY . .
CMD ["python", "bot.py"]
```

```bash
docker build -t telegram-agent .
docker run -d --name agent telegram-agent
```

---

## 📁 Project Structure

```
telegram-agent/
├── bot.py                  # Main bot — all Telegram handlers
├── config.py               # Credentials & constants
├── database.py             # Firebase REST API + encryption
├── ai_engine.py            # LLM integration (HF + 4 providers)
├── task_executor.py        # Task routing — AI + connectors
├── connectors/
│   ├── __init__.py
│   ├── base.py             # Abstract base class
│   ├── gmail_connector.py  # Gmail REST API
│   ├── gdrive_connector.py # Google Drive REST API
│   └── github_connector.py # GitHub REST API
├── setup_firebase.py       # One-time Firebase init
├── update_hf_key.py        # Update HF key without redeploy
├── requirements.txt
├── .env.example
└── README.md
```

---

## 🔧 Update HF API Key (Live, No Redeploy)

```bash
python update_hf_key.py hf_your_new_key_here
```

Or go directly to Firebase console:  
`https://eduweb-fcfee-default-rtdb.firebaseio.com/config/hf_api_key`

---

## 🔌 How to Get API Keys (for Users)

### Gmail / Google Drive
1. Go to [Google OAuth Playground](https://developers.google.com/oauthplayground)
2. Select Gmail API v1 (or Drive API v3)
3. Click "Authorize APIs" → sign in
4. Click "Exchange authorization code for tokens"
5. Copy the **Access Token**

> ⚠️ Access tokens expire after 1 hour. For production, set up a proper OAuth flow.

### GitHub
1. Go to GitHub → Settings → Developer settings
2. Personal access tokens → Tokens (classic)
3. Generate new token → select scopes: `repo`, `read:user`, `gist`
4. Copy the token

---

## 🔒 Firebase Security Rules

For production, update your Firebase Realtime Database rules:

```json
{
  "rules": {
    "users": {
      "$uid": {
        ".read":  false,
        ".write": false
      }
    },
    "config": {
      ".read":  false,
      ".write": false
    }
  }
}
```

Then add a **Database Secret** to authenticate your server requests.

---

## ➕ Adding New Connectors

1. Create `connectors/your_connector.py`:

```python
from connectors.base import BaseConnector

class YourConnector(BaseConnector):
    name        = "Your Service"
    description = "What it does"
    icon        = "🔧"

    async def execute(self, task: str, api_key: str) -> str:
        # Call your API here
        return "Result"
```

2. Add to `connectors/__init__.py`
3. Add entry to `CONNECTORS_CONFIG` in `config.py`
4. Register in `task_executor.py` intent map

---

## 💬 Bot Commands

| Command | Description |
|---|---|
| `/start` | Start or restart the bot |
| `/menu` | Open main menu |
| `/help` | Show help & examples |

---

## 📊 Firebase Data Structure

```json
{
  "config": {
    "hf_api_key": "hf_...",
    "free_message_limit": 4
  },
  "users": {
    "123456789": {
      "message_count": 2,
      "setup_complete": true,
      "ai_config": {
        "provider": "huggingface",
        "model": "Qwen/Qwen2.5-7B-Instruct",
        "api_key": null
      },
      "connectors": {
        "github": {
          "enabled": true,
          "api_key": "<encrypted>"
        }
      }
    }
  }
}
```

---

## 🛡️ Security Notes

- All API keys encrypted with **Fernet (AES-128)** before Firebase storage
- User messages containing API keys are **deleted immediately** from Telegram
- Encryption key stored in `.encryption_key` on the server — **back this up!**
- Keys are **never** logged or displayed

---

## 📝 License

MIT — free to use and modify.
