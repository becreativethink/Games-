"""
AI Engine — Supports multiple LLM providers.
Default: Hugging Face (Qwen 2.5 7B) — free up to FREE_MESSAGE_LIMIT messages.
Custom:  OpenAI · Google Gemini · Anthropic Claude · OpenRouter
"""

import logging
import requests
from config import FREE_MESSAGE_LIMIT, HF_DEFAULT_MODEL
from database import Database

logger = logging.getLogger(__name__)

# ── System prompt that turns the model into an autonomous agent ───────────────
AGENT_SYSTEM_PROMPT = """You are an advanced autonomous AI agent — like Manus AI — running inside Telegram.

You have access to the following connected tools:
{tools}

Your job:
1. Understand the user's task clearly.
2. Decide which tool(s) are best suited.
3. Break the task into logical steps.
4. Execute or describe the execution in a structured way.
5. Return a clean, friendly result.

Response format (always follow this):
🔍 **Analysis:** [What the task requires]
🛠️ **Tool:** [Which connector/tool to use — or "AI Only" if no connector needed]
📋 **Steps:**
  1. [Step 1]
  2. [Step 2]
  ...
✅ **Result:** [The outcome — be specific and helpful]

If a needed service isn't connected, suggest exactly how to connect it.
Be concise, action-oriented, and friendly. No technical jargon."""


class AIEngine:
    def __init__(self):
        self.db = Database()

    # ── Limit helpers ─────────────────────────────────────────────────────────
    def can_use_free(self, user_id: int) -> bool:
        return self.db.get_message_count(user_id) < FREE_MESSAGE_LIMIT

    def remaining_free(self, user_id: int) -> int:
        return max(0, FREE_MESSAGE_LIMIT - self.db.get_message_count(user_id))

    def is_using_custom_api(self, user_id: int) -> bool:
        cfg = self.db.get_ai_config(user_id)
        return bool(cfg.get("api_key")) and cfg.get("provider") != "huggingface"

    # ── Main entry point ──────────────────────────────────────────────────────
    async def generate(self, user_id: int, system_prompt: str, user_message: str) -> str:
        """
        Returns:
            Response text, or one of the sentinel strings:
            "FREE_LIMIT_REACHED" | "AI_ERROR"
        """
        cfg = self.db.get_ai_config(user_id)
        provider = cfg.get("provider", "huggingface")
        has_custom = bool(cfg.get("api_key"))

        # Route to appropriate provider
        if has_custom and provider != "huggingface":
            result = await self._call_custom(cfg, system_prompt, user_message)
        else:
            # Default free HF path
            if not self.can_use_free(user_id):
                return "FREE_LIMIT_REACHED"
            result = await self._call_huggingface(system_prompt, user_message)
            if result not in ("AI_ERROR",):
                self.db.increment_message_count(user_id)

        return result

    async def generate_agent(self, user_id: int, task: str, tools_desc: str) -> str:
        """Generate agent response with tool context injected."""
        system = AGENT_SYSTEM_PROMPT.format(tools=tools_desc)
        return await self.generate(user_id, system, task)

    # ── Hugging Face (default) ────────────────────────────────────────────────
    async def _call_huggingface(self, system: str, user_msg: str) -> str:
        hf_key = self.db.get_hf_api_key()
        url = (
            f"https://api-inference.huggingface.co/models/"
            f"{HF_DEFAULT_MODEL}/v1/chat/completions"
        )
        headers = {
            "Authorization": f"Bearer {hf_key}",
            "Content-Type":  "application/json",
        }
        payload = {
            "model": HF_DEFAULT_MODEL,
            "messages": [
                {"role": "system", "content": system},
                {"role": "user",   "content": user_msg},
            ],
            "max_tokens":  1024,
            "temperature": 0.7,
            "stream":      False,
        }
        try:
            r = requests.post(url, headers=headers, json=payload, timeout=90)
            if r.status_code == 200:
                return r.json()["choices"][0]["message"]["content"]
            logger.error(f"HF error {r.status_code}: {r.text[:300]}")
            return "AI_ERROR"
        except Exception as e:
            logger.error(f"HF exception: {e}")
            return "AI_ERROR"

    # ── Custom provider dispatcher ────────────────────────────────────────────
    async def _call_custom(self, cfg: dict, system: str, user_msg: str) -> str:
        provider = cfg.get("provider")
        model    = cfg.get("model")
        api_key  = cfg.get("api_key")
        try:
            if provider == "openai":
                return await self._call_openai(api_key, model, system, user_msg)
            elif provider == "gemini":
                return await self._call_gemini(api_key, model, system, user_msg)
            elif provider == "claude":
                return await self._call_claude(api_key, model, system, user_msg)
            elif provider == "openrouter":
                return await self._call_openrouter(api_key, model, system, user_msg)
            else:
                return "AI_ERROR"
        except Exception as e:
            logger.error(f"Custom AI ({provider}) error: {e}")
            return "AI_ERROR"

    # ── OpenAI ────────────────────────────────────────────────────────────────
    async def _call_openai(self, key, model, system, msg) -> str:
        r = requests.post(
            "https://api.openai.com/v1/chat/completions",
            headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"},
            json={
                "model": model,
                "messages": [
                    {"role": "system",  "content": system},
                    {"role": "user",    "content": msg},
                ],
                "max_tokens": 1024,
            },
            timeout=60,
        )
        if r.status_code == 200:
            return r.json()["choices"][0]["message"]["content"]
        logger.error(f"OpenAI {r.status_code}: {r.text[:200]}")
        return "AI_ERROR"

    # ── Google Gemini ─────────────────────────────────────────────────────────
    async def _call_gemini(self, key, model, system, msg) -> str:
        url = (
            f"https://generativelanguage.googleapis.com/v1beta/"
            f"models/{model}:generateContent?key={key}"
        )
        r = requests.post(
            url,
            json={
                "contents": [{"parts": [{"text": f"{system}\n\n{msg}"}]}],
                "generationConfig": {"maxOutputTokens": 1024},
            },
            timeout=60,
        )
        if r.status_code == 200:
            return r.json()["candidates"][0]["content"]["parts"][0]["text"]
        logger.error(f"Gemini {r.status_code}: {r.text[:200]}")
        return "AI_ERROR"

    # ── Anthropic Claude ──────────────────────────────────────────────────────
    async def _call_claude(self, key, model, system, msg) -> str:
        r = requests.post(
            "https://api.anthropic.com/v1/messages",
            headers={
                "x-api-key":         key,
                "anthropic-version": "2023-06-01",
                "Content-Type":      "application/json",
            },
            json={
                "model":      model,
                "max_tokens": 1024,
                "system":     system,
                "messages":   [{"role": "user", "content": msg}],
            },
            timeout=60,
        )
        if r.status_code == 200:
            return r.json()["content"][0]["text"]
        logger.error(f"Claude {r.status_code}: {r.text[:200]}")
        return "AI_ERROR"

    # ── OpenRouter ────────────────────────────────────────────────────────────
    async def _call_openrouter(self, key, model, system, msg) -> str:
        r = requests.post(
            "https://openrouter.ai/api/v1/chat/completions",
            headers={
                "Authorization": f"Bearer {key}",
                "Content-Type":  "application/json",
                "HTTP-Referer":  "https://telegram-agent-bot",
            },
            json={
                "model": model,
                "messages": [
                    {"role": "system", "content": system},
                    {"role": "user",   "content": msg},
                ],
            },
            timeout=60,
        )
        if r.status_code == 200:
            return r.json()["choices"][0]["message"]["content"]
        logger.error(f"OpenRouter {r.status_code}: {r.text[:200]}")
        return "AI_ERROR"
