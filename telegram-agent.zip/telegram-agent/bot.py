"""
Telegram AI Agent Bot — Main Entry Point
Full autonomous agent inside Telegram: setup → connect → task → execute.
"""

import asyncio
import logging
from telegram import (
    Update, InlineKeyboardButton, InlineKeyboardMarkup, BotCommand
)
from telegram.ext import (
    Application, CommandHandler, CallbackQueryHandler,
    MessageHandler, ConversationHandler, filters, ContextTypes,
)
from telegram.constants import ParseMode

from config import BOT_TOKEN, CONNECTORS_CONFIG, AI_PROVIDERS, FREE_MESSAGE_LIMIT
from database import Database
from ai_engine import AIEngine
from task_executor import TaskExecutor

logging.basicConfig(
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
    level=logging.INFO,
)
logging.getLogger("httpx").setLevel(logging.WARNING)
logger = logging.getLogger(__name__)

# ── Singletons ────────────────────────────────────────────────────────────────
db             = Database()
ai_engine      = AIEngine()
task_executor  = TaskExecutor()

# ── Conversation states ───────────────────────────────────────────────────────
(
    ST_CONNECTORS,       # selecting connectors (multi-select)
    ST_CONNECTOR_KEY,    # entering API key for a connector
    ST_AI_CHOICE,        # free vs custom AI
    ST_AI_PROVIDER,      # choose provider
    ST_AI_MODEL,         # choose / type model
    ST_AI_KEY,           # enter AI API key
    ST_TASK_INPUT,       # enter task prompt
) = range(7)


# ══════════════════════════════════════════════════════════════════════════════
# KEYBOARDS
# ══════════════════════════════════════════════════════════════════════════════

def kb_main(user_id: int) -> InlineKeyboardMarkup:
    rem  = ai_engine.remaining_free(user_id)
    free = f" ({rem} free left)" if not ai_engine.is_using_custom_api(user_id) else ""
    return InlineKeyboardMarkup([
        [InlineKeyboardButton(f"🚀 Run Task{free}", callback_data="run_task")],
        [InlineKeyboardButton("🔌 Manage Connectors",    callback_data="manage_connectors")],
        [InlineKeyboardButton("🤖 AI Settings",          callback_data="ai_settings")],
        [InlineKeyboardButton("❓ Help",                  callback_data="show_help"),
         InlineKeyboardButton("🗑️ Reset",                callback_data="reset")],
    ])


def kb_connectors(selected: list) -> InlineKeyboardMarkup:
    rows = []
    for cid, info in CONNECTORS_CONFIG.items():
        tick = "✅ " if cid in selected else "⬜ "
        rows.append([InlineKeyboardButton(
            f"{tick}{info['icon']} {info['name']}",
            callback_data=f"tc_{cid}",   # tc = toggle connector
        )])
    rows.append([
        InlineKeyboardButton("➡️ Continue", callback_data="connectors_done"),
        InlineKeyboardButton("⏭️ Skip All",  callback_data="skip_connectors"),
    ])
    return InlineKeyboardMarkup(rows)


def kb_back_main() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([[
        InlineKeyboardButton("🏠 Main Menu", callback_data="main_menu")
    ]])


# ══════════════════════════════════════════════════════════════════════════════
# /start COMMAND
# ══════════════════════════════════════════════════════════════════════════════

async def cmd_start(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    uid  = update.effective_user.id
    name = update.effective_user.first_name
    db.get_user(uid)   # ensure user record exists

    text = (
        f"👋 *Welcome, {name}\\!*\n\n"
        "I'm your *AI Agent* — an autonomous assistant that lives inside Telegram\\.\n\n"
        "🔥 *What I can do:*\n"
        "• 📧 Read & summarise your Gmail\n"
        "• 📁 Browse & manage Google Drive\n"
        "• 🐙 List repos, issues, PRs on GitHub\n"
        "• 🧠 Answer anything with AI \\(Qwen 2\\.5 7B, GPT\\-4o, Gemini, Claude…\\)\n\n"
        f"⚡ *Free tier:* {FREE_MESSAGE_LIMIT} messages · then add your own API key\n\n"
        "_Setup takes under 60 seconds\\. Let's go\\!_"
    )

    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("🚀 Start Setup",             callback_data="start_setup")],
        [InlineKeyboardButton("⚡ Skip Setup (AI-only)",    callback_data="quick_demo")],
    ])
    await update.message.reply_text(text, reply_markup=kb, parse_mode=ParseMode.MARKDOWN_V2)


async def cmd_menu(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    await update.message.reply_text(
        "🤖 *AI Agent — Main Menu*",
        reply_markup=kb_main(uid),
        parse_mode=ParseMode.MARKDOWN_V2,
    )


async def cmd_help(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(_help_text(), parse_mode=ParseMode.MARKDOWN_V2)


def _help_text() -> str:
    return (
        "🤖 *AI Agent — Help*\n\n"
        "*Commands:*\n"
        "/start — Restart the bot\n"
        "/menu — Open main menu\n"
        "/help — This help\n\n"
        "*How it works:*\n"
        "1️⃣ Connect your services \\(Gmail, Drive, GitHub\\)\n"
        "2️⃣ Type any task in plain English\n"
        "3️⃣ AI executes it automatically\n\n"
        "*Example tasks:*\n"
        "• _Summarise my latest emails_\n"
        "• _List my GitHub repositories_\n"
        "• _Show recent Drive files_\n"
        "• _What are my open issues?_\n\n"
        "*Free limit:* 4 messages · Add your own API for unlimited\n\n"
        "*Security:* All keys are AES\\-encrypted before storage\n"
        "_Your data is never shared or logged\\._"
    )


# ══════════════════════════════════════════════════════════════════════════════
# SETUP FLOW — Step 1: Choose Connectors
# ══════════════════════════════════════════════════════════════════════════════

async def cb_start_setup(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    ctx.user_data["sel_connectors"] = []

    await q.edit_message_text(
        "🔌 *Step 1 of 3 — Choose Services*\n\n"
        "Tap to select the services you want to connect\\.\n"
        "You can select multiple\\. Skip if you want AI\\-only mode\\.",
        reply_markup=kb_connectors([]),
        parse_mode=ParseMode.MARKDOWN_V2,
    )
    return ST_CONNECTORS


async def cb_toggle_connector(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q   = update.callback_query
    await q.answer()
    cid = q.data[3:]   # strip "tc_"
    sel = ctx.user_data.setdefault("sel_connectors", [])

    if cid in sel:
        sel.remove(cid)
    else:
        sel.append(cid)

    count = len(sel)
    await q.edit_message_text(
        f"🔌 *Step 1 of 3 — Choose Services*\n\n"
        f"Selected: *{count}* service\\(s\\)\n"
        "_Tap to toggle · tap Continue when done\\._",
        reply_markup=kb_connectors(sel),
        parse_mode=ParseMode.MARKDOWN_V2,
    )
    return ST_CONNECTORS


async def cb_skip_connectors(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    ctx.user_data["sel_connectors"] = []
    ctx.user_data["conn_queue"]     = []
    return await _show_ai_choice(q, ctx)


async def cb_connectors_done(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q   = update.callback_query
    await q.answer()
    sel = ctx.user_data.get("sel_connectors", [])
    ctx.user_data["conn_queue"] = list(sel)

    if not sel:
        return await _show_ai_choice(q, ctx)
    return await _ask_connector_key(q, ctx)


# ── Step 2: Collect API keys ──────────────────────────────────────────────────

async def _ask_connector_key(target, ctx: ContextTypes.DEFAULT_TYPE):
    queue = ctx.user_data.get("conn_queue", [])
    if not queue:
        return await _show_ai_choice(target, ctx)

    cid  = queue[0]
    info = CONNECTORS_CONFIG[cid]
    ctx.user_data["cur_connector"] = cid

    kb = InlineKeyboardMarkup([[
        InlineKeyboardButton("⏭️ Skip This Service", callback_data="skip_cur_connector")
    ],[
        InlineKeyboardButton("📖 How to get this key?", callback_data=f"help_key_{cid}")
    ]])

    text = (
        f"🔑 *Step 2 — Connect {info['icon']} {info['name']}*\n\n"
        f"_{info['description']}_\n\n"
        f"Please paste your *{info['fields'][0]}* below\\.\n\n"
        "🔒 _Your key is encrypted immediately and never shown again\\._\n"
        "_Type_ `SKIP` _to skip this service\\._"
    )

    if hasattr(target, "edit_message_text"):
        await target.edit_message_text(text, reply_markup=kb, parse_mode=ParseMode.MARKDOWN_V2)
    else:
        await target.message.reply_text(text, reply_markup=kb, parse_mode=ParseMode.MARKDOWN_V2)

    return ST_CONNECTOR_KEY


async def cb_show_key_help(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q   = update.callback_query
    await q.answer()
    cid  = q.data.replace("help_key_", "")
    info = CONNECTORS_CONFIG.get(cid, {})
    help_text = info.get("help", "No help available.")
    await q.answer(help_text, show_alert=True)
    return ST_CONNECTOR_KEY


async def cb_skip_cur_connector(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    queue = ctx.user_data.get("conn_queue", [])
    if queue:
        queue.pop(0)
    return await _ask_connector_key(q, ctx)


async def msg_connector_key(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    uid     = update.effective_user.id
    raw_key = update.message.text.strip()

    # Immediately delete the message for security
    try:
        await update.message.delete()
    except Exception:
        pass

    if raw_key.upper() == "SKIP":
        queue = ctx.user_data.get("conn_queue", [])
        if queue:
            queue.pop(0)
        # send a new message to continue (can't edit deleted msg)
        fake = await ctx.bot.send_message(
            update.effective_chat.id,
            "⏭️ Skipped. Continuing…",
        )
        ctx.user_data["_last_msg_id"] = fake.message_id
        return await _ask_connector_key_via_bot(ctx, update.effective_chat.id)

    cid   = ctx.user_data.get("cur_connector")
    info  = CONNECTORS_CONFIG.get(cid, {})
    queue = ctx.user_data.get("conn_queue", [])

    if cid:
        db.save_connector(uid, cid, raw_key)
        if queue and queue[0] == cid:
            queue.pop(0)

    confirm_msg = await ctx.bot.send_message(
        update.effective_chat.id,
        f"✅ *{info.get('icon','')} {info.get('name', cid)} connected\\!*\n"
        "_Key saved securely\\._",
        parse_mode=ParseMode.MARKDOWN_V2,
    )
    ctx.user_data["_last_msg_id"] = confirm_msg.message_id

    if queue:
        return await _ask_connector_key_via_bot(ctx, update.effective_chat.id)
    else:
        return await _show_ai_choice_via_bot(ctx, update.effective_chat.id)


async def _ask_connector_key_via_bot(ctx: ContextTypes.DEFAULT_TYPE, chat_id: int):
    queue = ctx.user_data.get("conn_queue", [])
    if not queue:
        return await _show_ai_choice_via_bot(ctx, chat_id)

    cid  = queue[0]
    info = CONNECTORS_CONFIG[cid]
    ctx.user_data["cur_connector"] = cid

    kb = InlineKeyboardMarkup([[
        InlineKeyboardButton("⏭️ Skip This Service",    callback_data="skip_cur_connector")
    ],[
        InlineKeyboardButton("📖 How to get this key?", callback_data=f"help_key_{cid}")
    ]])

    await ctx.bot.send_message(
        chat_id,
        f"🔑 *Connect {info['icon']} {info['name']}*\n\n"
        f"Paste your *{info['fields'][0]}*:\n\n"
        "🔒 _Encrypted · message deleted automatically_",
        reply_markup=kb,
        parse_mode=ParseMode.MARKDOWN_V2,
    )
    return ST_CONNECTOR_KEY


# ── Step 3: AI Configuration ──────────────────────────────────────────────────

async def _show_ai_choice(target, ctx: ContextTypes.DEFAULT_TYPE):
    uid = target.from_user.id if hasattr(target, "from_user") else 0
    rem = ai_engine.remaining_free(uid)
    kb  = InlineKeyboardMarkup([
        [InlineKeyboardButton(f"⚡ Use Free Default ({rem}/{FREE_MESSAGE_LIMIT} left)", callback_data="use_default_ai")],
        [InlineKeyboardButton("🔑 Use My Own API (Unlimited)",                         callback_data="use_custom_ai")],
    ])
    text = (
        "🤖 *Step 3 of 3 — AI Configuration*\n\n"
        f"*Free default:* Qwen 2\\.5 7B via Hugging Face\n"
        f"*Remaining free messages:* {rem}/{FREE_MESSAGE_LIMIT}\n\n"
        "After the limit, you'll need your own API key\\.\n"
        "Custom APIs are *unlimited* and support GPT\\-4o, Gemini, Claude and more\\."
    )
    if hasattr(target, "edit_message_text"):
        await target.edit_message_text(text, reply_markup=kb, parse_mode=ParseMode.MARKDOWN_V2)
    else:
        await target.message.reply_text(text, reply_markup=kb, parse_mode=ParseMode.MARKDOWN_V2)
    return ST_AI_CHOICE


async def _show_ai_choice_via_bot(ctx: ContextTypes.DEFAULT_TYPE, chat_id: int):
    rem = 0
    kb  = InlineKeyboardMarkup([
        [InlineKeyboardButton(f"⚡ Free Default ({rem}/{FREE_MESSAGE_LIMIT} left)", callback_data="use_default_ai")],
        [InlineKeyboardButton("🔑 Use My Own API (Unlimited)",                     callback_data="use_custom_ai")],
    ])
    await ctx.bot.send_message(
        chat_id,
        "🤖 *Step 3 of 3 — AI Configuration*\n\n"
        "Choose how the agent thinks:",
        reply_markup=kb,
        parse_mode=ParseMode.MARKDOWN_V2,
    )
    return ST_AI_CHOICE


async def cb_use_default_ai(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q   = update.callback_query
    await q.answer()
    uid = q.from_user.id
    db.clear_ai_config(uid)
    db.mark_setup_complete(uid)

    await q.edit_message_text(
        "🎉 *Setup Complete\\!*\n\n"
        "You're all set\\. Here's what you can do:\n\n"
        "🚀 *Run Task* — Type any task, AI executes it\n"
        "🔌 *Manage Connectors* — Add or remove services\n"
        "🤖 *AI Settings* — Switch to a paid provider\n\n"
        "_Try: 'Summarise my latest emails' or 'List my GitHub repos'_",
        reply_markup=kb_main(uid),
        parse_mode=ParseMode.MARKDOWN_V2,
    )
    return ConversationHandler.END


async def cb_use_custom_ai(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()

    rows = []
    for pid, pinfo in AI_PROVIDERS.items():
        rows.append([InlineKeyboardButton(pinfo["name"], callback_data=f"ai_prov_{pid}")])

    await q.edit_message_text(
        "🤖 *Choose AI Provider:*\n\nWhich service do you prefer?",
        reply_markup=InlineKeyboardMarkup(rows),
        parse_mode=ParseMode.MARKDOWN_V2,
    )
    return ST_AI_PROVIDER


async def cb_select_provider(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q    = update.callback_query
    await q.answer()
    pid  = q.data.replace("ai_prov_", "")
    ctx.user_data["ai_provider"] = pid
    info = AI_PROVIDERS.get(pid, {})

    if pid == "openrouter":
        await q.edit_message_text(
            f"✅ *{info['name']}* selected\\.\n\n"
            "Type the exact model string \\(e\\.g\\. `anthropic/claude-3-5-sonnet`\\):",
            parse_mode=ParseMode.MARKDOWN_V2,
        )
        return ST_AI_MODEL

    rows = [[InlineKeyboardButton(m, callback_data=f"ai_mdl_{m}")] for m in info["models"]]
    rows.append([InlineKeyboardButton("✏️ Custom model name", callback_data="ai_mdl_custom")])
    await q.edit_message_text(
        f"✅ *{info['name']}* — Choose a model:",
        reply_markup=InlineKeyboardMarkup(rows),
        parse_mode=ParseMode.MARKDOWN_V2,
    )
    return ST_AI_MODEL


async def cb_select_model(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()

    if q.data == "ai_mdl_custom":
        await q.edit_message_text(
            "✏️ *Enter custom model name:*\n\nType the exact model string below:",
            parse_mode=ParseMode.MARKDOWN_V2,
        )
        return ST_AI_MODEL

    model = q.data.replace("ai_mdl_", "")
    ctx.user_data["ai_model"] = model
    await q.edit_message_text(
        f"✅ Model: `{model}`\n\n"
        "🔑 *Now paste your API key:*\n\n"
        "_It will be deleted from chat immediately\\._",
        parse_mode=ParseMode.MARKDOWN_V2,
    )
    return ST_AI_KEY


async def msg_custom_model(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    model = update.message.text.strip()
    try:
        await update.message.delete()
    except Exception:
        pass
    ctx.user_data["ai_model"] = model
    await ctx.bot.send_message(
        update.effective_chat.id,
        f"✅ Model: `{model}`\n\n"
        "🔑 *Now paste your API key:*\n\n"
        "_Deleted immediately for security\\._",
        parse_mode=ParseMode.MARKDOWN_V2,
    )
    return ST_AI_KEY


async def msg_ai_key(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    key = update.message.text.strip()
    try:
        await update.message.delete()
    except Exception:
        pass

    provider = ctx.user_data.get("ai_provider", "openai")
    model    = ctx.user_data.get("ai_model",    "gpt-4o")
    db.save_ai_config(uid, provider, model, key)
    db.mark_setup_complete(uid)

    pname = AI_PROVIDERS.get(provider, {}).get("name", provider)
    await ctx.bot.send_message(
        update.effective_chat.id,
        f"✅ *{pname}* configured\\!\n"
        f"Model: `{model}`\n\n"
        "🎉 *Setup complete\\!* Ready to work\\.\n"
        "_Your API key is encrypted and stored securely\\._",
        reply_markup=kb_main(uid),
        parse_mode=ParseMode.MARKDOWN_V2,
    )
    return ConversationHandler.END


# ══════════════════════════════════════════════════════════════════════════════
# TASK EXECUTION
# ══════════════════════════════════════════════════════════════════════════════

async def cb_run_task(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q   = update.callback_query
    await q.answer()
    uid = q.from_user.id

    active = db.get_active_connectors(uid)
    conn_str = ", ".join(active) if active else "none \\(AI\\-only mode\\)"

    suggestions = [
        "💡 _Summarise my latest Gmail emails_",
        "💡 _List my GitHub repositories_",
        "💡 _Show recent Google Drive files_",
        "💡 _What are my open GitHub issues?_",
        "💡 _Any AI question — no connector needed_",
    ]
    # Show relevant suggestions based on active connectors
    shown = []
    if "gmail"  in active: shown.append(suggestions[0])
    if "github" in active: shown.append(suggestions[1]); shown.append(suggestions[3])
    if "gdrive" in active: shown.append(suggestions[2])
    shown.append(suggestions[4])

    await q.edit_message_text(
        f"🚀 *What task should I execute?*\n\n"
        f"Connected: {conn_str}\n\n"
        "*Ideas:*\n" + "\n".join(shown[:4]) + "\n\n"
        "*Type your task below:*",
        parse_mode=ParseMode.MARKDOWN_V2,
    )
    return ST_TASK_INPUT


async def msg_execute_task(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    uid  = update.effective_user.id
    task = update.message.text.strip()

    # Show typing indicator
    thinking = await update.message.reply_text(
        "🧠 *AI Agent is working\\.\\.\\.*\n\n⏳ Analysing your task\\.\\.\\.",
        parse_mode=ParseMode.MARKDOWN_V2,
    )

    try:
        result = await task_executor.run(uid, task)

        if result["status"] == "free_limit":
            await thinking.edit_text(
                "⚠️ *Free Limit Reached\\!*\n\n"
                f"You've used all {FREE_MESSAGE_LIMIT} free messages\\.\n\n"
                "Add your own API key to continue with unlimited access\\.",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("🔑 Add API Key", callback_data="use_custom_ai")],
                    [InlineKeyboardButton("🏠 Main Menu",   callback_data="main_menu")],
                ]),
                parse_mode=ParseMode.MARKDOWN_V2,
            )
            return ConversationHandler.END

        if result["status"] == "error":
            await thinking.edit_text(
                "❌ *Something went wrong\\.*\n\n"
                "The AI couldn't process your request\\. Please try again\\.",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("🔄 Try Again", callback_data="run_task")],
                    [InlineKeyboardButton("🏠 Main Menu", callback_data="main_menu")],
                ]),
                parse_mode=ParseMode.MARKDOWN_V2,
            )
            return ConversationHandler.END

        # Build the response
        ai_out   = result.get("ai_output",        "") or ""
        conn_out = result.get("connector_output", "") or ""

        parts = []

        if conn_out:
            parts.append(conn_out)
            parts.append("")

        if ai_out:
            # Truncate if very long
            ai_preview = ai_out[:1200] + ("…" if len(ai_out) > 1200 else "")
            parts.append("🧠 *AI Analysis:*\n" + ai_preview)

        response = "\n".join(parts).strip() or "✅ Task completed."

        # Remaining free messages note
        if not ai_engine.is_using_custom_api(uid):
            rem = ai_engine.remaining_free(uid)
            response += f"\n\n_⚡ Free messages remaining: {rem}/{FREE_MESSAGE_LIMIT}_"

        kb = InlineKeyboardMarkup([
            [InlineKeyboardButton("🔄 Run Another Task", callback_data="run_task")],
            [InlineKeyboardButton("🏠 Main Menu",        callback_data="main_menu")],
        ])

        # Edit in chunks if too long for a single edit
        try:
            await thinking.edit_text(
                "✅ *Task Complete\\!*\n\n" + _escape(response),
                reply_markup=kb,
                parse_mode=ParseMode.MARKDOWN_V2,
            )
        except Exception:
            # Fallback: send plain text
            await thinking.edit_text(
                "✅ Task Complete!\n\n" + response[:3500],
                reply_markup=kb,
            )

    except Exception as e:
        logger.error(f"Task execution outer error: {e}", exc_info=True)
        await thinking.edit_text(
            "❌ *Something went wrong\\. Try again or contact support\\.*",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🔄 Retry",    callback_data="run_task")],
                [InlineKeyboardButton("🏠 Main Menu", callback_data="main_menu")],
            ]),
            parse_mode=ParseMode.MARKDOWN_V2,
        )

    return ConversationHandler.END


def _escape(text: str) -> str:
    """Escape special Markdown V2 characters (preserves * _ ` already in use)."""
    # We only escape characters that would break rendering but aren't intentional markup
    for ch in [".", "(", ")", "-", "!", "+"]:
        text = text.replace(ch, f"\\{ch}")
    return text


# ══════════════════════════════════════════════════════════════════════════════
# MENU / SETTINGS CALLBACKS
# ══════════════════════════════════════════════════════════════════════════════

async def cb_main_menu(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q   = update.callback_query
    await q.answer()
    uid = q.from_user.id

    active = db.get_active_connectors(uid)
    rem    = ai_engine.remaining_free(uid)
    using  = "Custom API" if ai_engine.is_using_custom_api(uid) else f"Free ({rem} left)"

    conn_str = ", ".join(active) if active else "None"

    await q.edit_message_text(
        f"🤖 *AI Agent — Main Menu*\n\n"
        f"🔌 Connected: {conn_str}\n"
        f"🧠 AI: {using}\n\n"
        "_What would you like to do?_",
        reply_markup=kb_main(uid),
        parse_mode=ParseMode.MARKDOWN_V2,
    )


async def cb_manage_connectors(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q   = update.callback_query
    await q.answer()
    uid = q.from_user.id

    all_conns = db.get_all_connectors(uid)
    rows = []
    for cid, info in CONNECTORS_CONFIG.items():
        is_on  = cid in all_conns and all_conns[cid].get("enabled")
        status = "✅" if is_on else "❌"
        rows.append([InlineKeyboardButton(
            f"{status} {info['icon']} {info['name']}",
            callback_data=f"conn_manage_{cid}",
        )])
    rows.append([InlineKeyboardButton("🔙 Back", callback_data="main_menu")])

    await q.edit_message_text(
        "🔌 *Manage Connectors*\n\nTap a service to update or disconnect it:",
        reply_markup=InlineKeyboardMarkup(rows),
        parse_mode=ParseMode.MARKDOWN_V2,
    )


async def cb_connector_manage_one(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q   = update.callback_query
    await q.answer()
    cid  = q.data.replace("conn_manage_", "")
    info = CONNECTORS_CONFIG.get(cid, {})

    ctx.user_data["cur_connector"] = cid
    ctx.user_data["conn_queue"]    = [cid]

    uid       = q.from_user.id
    all_conns = db.get_all_connectors(uid)
    is_on     = cid in all_conns and all_conns[cid].get("enabled")
    status    = "✅ Connected" if is_on else "❌ Not connected"

    await q.edit_message_text(
        f"{info.get('icon','')} *{info.get('name', cid)}*\n"
        f"_{info.get('description','')}_\n\n"
        f"Status: {status}",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("🔑 Update API Key",   callback_data=f"upd_key_{cid}")],
            [InlineKeyboardButton("❌ Disconnect",        callback_data=f"disc_{cid}")],
            [InlineKeyboardButton("🔙 Back",             callback_data="manage_connectors")],
        ]),
        parse_mode=ParseMode.MARKDOWN_V2,
    )


async def cb_update_key(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q   = update.callback_query
    await q.answer()
    cid  = q.data.replace("upd_key_", "")
    info = CONNECTORS_CONFIG.get(cid, {})

    ctx.user_data["cur_connector"] = cid
    ctx.user_data["conn_queue"]    = [cid]

    await q.edit_message_text(
        f"🔑 *Update {info.get('icon','')} {info.get('name', cid)}*\n\n"
        f"Paste your new *{info.get('fields', ['API Key'])[0]}*:\n\n"
        "_Message deleted immediately\\._",
        parse_mode=ParseMode.MARKDOWN_V2,
    )
    return ST_CONNECTOR_KEY


async def cb_disconnect(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q   = update.callback_query
    await q.answer()
    uid  = q.from_user.id
    cid  = q.data.replace("disc_", "")
    info = CONNECTORS_CONFIG.get(cid, {})

    db.remove_connector(uid, cid)
    await q.edit_message_text(
        f"✅ *{info.get('icon','')} {info.get('name', cid)} disconnected\\.*\n\n"
        "Credentials removed\\.",
        reply_markup=InlineKeyboardMarkup([[
            InlineKeyboardButton("🔙 Back to Connectors", callback_data="manage_connectors")
        ]]),
        parse_mode=ParseMode.MARKDOWN_V2,
    )


async def cb_ai_settings(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q   = update.callback_query
    await q.answer()
    uid = q.from_user.id

    cfg      = db.get_ai_config(uid)
    provider = cfg.get("provider", "huggingface")
    model    = cfg.get("model", "Qwen/Qwen2.5-7B-Instruct")
    rem      = ai_engine.remaining_free(uid)

    if ai_engine.is_using_custom_api(uid):
        pname  = AI_PROVIDERS.get(provider, {}).get("name", provider)
        status = f"Using: *{pname}* / `{model}`\n_Unlimited messages_"
    else:
        status = f"Using: *Free Default* \\(Qwen 2\\.5 7B\\)\n_Remaining: {rem}/{FREE_MESSAGE_LIMIT}_"

    await q.edit_message_text(
        f"🤖 *AI Settings*\n\n{status}",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("🔄 Switch to Custom API", callback_data="use_custom_ai")],
            [InlineKeyboardButton("⚡ Use Free Default",      callback_data="use_default_ai")],
            [InlineKeyboardButton("🔙 Back",                  callback_data="main_menu")],
        ]),
        parse_mode=ParseMode.MARKDOWN_V2,
    )


async def cb_show_help(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    await q.edit_message_text(
        _help_text(),
        reply_markup=kb_back_main(),
        parse_mode=ParseMode.MARKDOWN_V2,
    )


async def cb_reset(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    await q.edit_message_text(
        "⚠️ *Are you sure you want to reset?*\n\n"
        "This will delete:\n"
        "• All connected services\n"
        "• Your AI configuration\n"
        "• Your message count\n\n"
        "_This cannot be undone\\._",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("⚠️ Yes, Reset Everything", callback_data="confirm_reset")],
            [InlineKeyboardButton("❌ Cancel",                  callback_data="main_menu")],
        ]),
        parse_mode=ParseMode.MARKDOWN_V2,
    )


async def cb_confirm_reset(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q   = update.callback_query
    await q.answer()
    uid = q.from_user.id
    db.reset_user(uid)
    ctx.user_data.clear()

    await q.edit_message_text(
        "✅ *Everything has been reset\\.*\n\nStart fresh below\\!",
        reply_markup=InlineKeyboardMarkup([[
            InlineKeyboardButton("🚀 Start Setup", callback_data="start_setup")
        ]]),
        parse_mode=ParseMode.MARKDOWN_V2,
    )


async def cb_quick_demo(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q   = update.callback_query
    await q.answer()
    uid = q.from_user.id
    db.mark_setup_complete(uid)

    await q.edit_message_text(
        "⚡ *Quick Demo Mode*\n\n"
        "You're in\\! No connectors needed for a quick demo\\.\n\n"
        "Ask me anything — I'll use AI to respond\\.\n"
        "_Some actions require connected services\\._",
        reply_markup=kb_main(uid),
        parse_mode=ParseMode.MARKDOWN_V2,
    )


# ── Fallback for unrecognised text ────────────────────────────────────────────
async def msg_fallback(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    await update.message.reply_text(
        "Tap *🚀 Run Task* to execute a task, or /menu to see all options\\.",
        reply_markup=kb_main(uid),
        parse_mode=ParseMode.MARKDOWN_V2,
    )


# ══════════════════════════════════════════════════════════════════════════════
# BOT SETUP
# ══════════════════════════════════════════════════════════════════════════════

def build_app() -> Application:
    app = Application.builder().token(BOT_TOKEN).build()

    # ── ConversationHandler (setup + task) ────────────────────────────────────
    conv = ConversationHandler(
        entry_points=[
            CallbackQueryHandler(cb_start_setup,    pattern="^start_setup$"),
            CallbackQueryHandler(cb_run_task,        pattern="^run_task$"),
            CallbackQueryHandler(cb_use_custom_ai,   pattern="^use_custom_ai$"),
            CallbackQueryHandler(cb_update_key,      pattern=r"^upd_key_"),
        ],
        states={
            ST_CONNECTORS: [
                CallbackQueryHandler(cb_toggle_connector,   pattern=r"^tc_"),
                CallbackQueryHandler(cb_connectors_done,    pattern="^connectors_done$"),
                CallbackQueryHandler(cb_skip_connectors,    pattern="^skip_connectors$"),
            ],
            ST_CONNECTOR_KEY: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, msg_connector_key),
                CallbackQueryHandler(cb_skip_cur_connector, pattern="^skip_cur_connector$"),
                CallbackQueryHandler(cb_show_key_help,      pattern=r"^help_key_"),
            ],
            ST_AI_CHOICE: [
                CallbackQueryHandler(cb_use_default_ai, pattern="^use_default_ai$"),
                CallbackQueryHandler(cb_use_custom_ai,  pattern="^use_custom_ai$"),
            ],
            ST_AI_PROVIDER: [
                CallbackQueryHandler(cb_select_provider, pattern=r"^ai_prov_"),
            ],
            ST_AI_MODEL: [
                CallbackQueryHandler(cb_select_model,   pattern=r"^ai_mdl_"),
                MessageHandler(filters.TEXT & ~filters.COMMAND, msg_custom_model),
            ],
            ST_AI_KEY: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, msg_ai_key),
            ],
            ST_TASK_INPUT: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, msg_execute_task),
            ],
        },
        fallbacks=[
            CommandHandler("start", cmd_start),
            CommandHandler("menu",  cmd_menu),
            CallbackQueryHandler(cb_main_menu, pattern="^main_menu$"),
        ],
        allow_reentry=True,
        per_message=False,
    )

    # ── Register handlers (order matters) ────────────────────────────────────
    app.add_handler(CommandHandler("start", cmd_start))
    app.add_handler(CommandHandler("menu",  cmd_menu))
    app.add_handler(CommandHandler("help",  cmd_help))
    app.add_handler(conv)

    # Non-conversation callbacks
    app.add_handler(CallbackQueryHandler(cb_main_menu,              pattern="^main_menu$"))
    app.add_handler(CallbackQueryHandler(cb_manage_connectors,      pattern="^manage_connectors$"))
    app.add_handler(CallbackQueryHandler(cb_connector_manage_one,   pattern=r"^conn_manage_"))
    app.add_handler(CallbackQueryHandler(cb_disconnect,             pattern=r"^disc_"))
    app.add_handler(CallbackQueryHandler(cb_ai_settings,            pattern="^ai_settings$"))
    app.add_handler(CallbackQueryHandler(cb_show_help,              pattern="^show_help$"))
    app.add_handler(CallbackQueryHandler(cb_reset,                  pattern="^reset$"))
    app.add_handler(CallbackQueryHandler(cb_confirm_reset,          pattern="^confirm_reset$"))
    app.add_handler(CallbackQueryHandler(cb_quick_demo,             pattern="^quick_demo$"))
    app.add_handler(CallbackQueryHandler(cb_use_default_ai,         pattern="^use_default_ai$"))

    # Fallback text
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, msg_fallback))

    return app


async def post_init(app: Application):
    await app.bot.set_my_commands([
        BotCommand("start", "Start / restart the bot"),
        BotCommand("menu",  "Open main menu"),
        BotCommand("help",  "Show help & examples"),
    ])
    logger.info("✅ Bot commands set.")


def main():
    app = build_app()
    app.post_init = post_init
    logger.info("🤖 AI Agent Bot is starting…")
    app.run_polling(allowed_updates=Update.ALL_TYPES, drop_pending_updates=True)


if __name__ == "__main__":
    main()
