"""
Configuration — Telegram AI Agent
All sensitive values are loaded from .env or hardcoded defaults.
The HF API key is also editable live via Firebase: config/hf_api_key
"""

import os
from dotenv import load_dotenv

load_dotenv()

# ─── Core Credentials ────────────────────────────────────────────────────────
BOT_TOKEN   = os.getenv("BOT_TOKEN",    "8458867138:AAHJtr1tAkMvlWdlCuONzwsXVh6fsA2YmAk")
HF_API_KEY  = os.getenv("HF_API_KEY",  "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")
FIREBASE_URL= os.getenv("FIREBASE_URL","https://eduweb-fcfee-default-rtdb.firebaseio.com")

# ─── Free Tier Limit ─────────────────────────────────────────────────────────
FREE_MESSAGE_LIMIT = 4

# ─── Default HF Model ────────────────────────────────────────────────────────
HF_DEFAULT_MODEL = "Qwen/Qwen2.5-7B-Instruct"

# ─── Connector Definitions ───────────────────────────────────────────────────
CONNECTORS_CONFIG = {
    "gmail": {
        "name":        "Gmail",
        "icon":        "📧",
        "description": "Read, summarize and send emails",
        "fields":      ["Gmail OAuth Access Token"],
        "help":        (
            "Get your Gmail access token:\n"
            "1. Go to https://developers.google.com/oauthplayground\n"
            "2. Select Gmail API v1 → Authorize\n"
            "3. Exchange code → copy Access Token"
        ),
    },
    "gdrive": {
        "name":        "Google Drive",
        "icon":        "📁",
        "description": "List, upload and download files",
        "fields":      ["Google Drive OAuth Access Token"],
        "help":        (
            "Get your Drive access token:\n"
            "1. Go to https://developers.google.com/oauthplayground\n"
            "2. Select Drive API v3 → Authorize\n"
            "3. Exchange code → copy Access Token"
        ),
    },
    "github": {
        "name":        "GitHub",
        "icon":        "🐙",
        "description": "Manage repos, issues and code",
        "fields":      ["GitHub Personal Access Token"],
        "help":        (
            "Get your GitHub token:\n"
            "1. Go to GitHub → Settings → Developer settings\n"
            "2. Personal access tokens → Tokens (classic)\n"
            "3. Generate new token → copy it"
        ),
    },
}

# ─── AI Provider Definitions ─────────────────────────────────────────────────
AI_PROVIDERS = {
    "gemini": {
        "name":   "Google Gemini",
        "models": ["gemini-1.5-pro", "gemini-1.5-flash", "gemini-pro"],
    },
    "openai": {
        "name":   "OpenAI (ChatGPT)",
        "models": ["gpt-4o", "gpt-4o-mini", "gpt-4-turbo", "gpt-3.5-turbo"],
    },
    "claude": {
        "name":   "Anthropic Claude",
        "models": ["claude-opus-4-5", "claude-sonnet-4-5", "claude-haiku-4-5-20251001"],
    },
    "openrouter": {
        "name":   "OpenRouter",
        "models": ["custom"],
    },
}
