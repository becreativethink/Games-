"""Base class for all connectors."""

from abc import ABC, abstractmethod


class BaseConnector(ABC):
    name: str        = "Connector"
    description: str = ""
    icon: str        = "🔌"

    @abstractmethod
    async def execute(self, task: str, api_key: str) -> str:
        """Execute a task using the connector. Returns a Markdown result string."""
        ...

    def _err(self, msg: str) -> str:
        return f"❌ {self.name} error: {msg}"
