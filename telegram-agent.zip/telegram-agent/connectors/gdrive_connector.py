"""Google Drive Connector — uses Drive REST API v3 with OAuth Access Token."""

import logging
import requests
from connectors.base import BaseConnector

logger = logging.getLogger(__name__)

MIME_ICONS = {
    "application/vnd.google-apps.folder":       "📁",
    "application/vnd.google-apps.document":     "📄",
    "application/vnd.google-apps.spreadsheet":  "📊",
    "application/vnd.google-apps.presentation": "📽️",
    "application/vnd.google-apps.form":         "📋",
    "image/":                                   "🖼️",
    "video/":                                   "🎬",
    "audio/":                                   "🎵",
    "application/pdf":                          "📑",
    "application/zip":                          "🗜️",
}


def _icon(mime: str) -> str:
    for prefix, icon in MIME_ICONS.items():
        if mime.startswith(prefix):
            return icon
    return "📎"


class GDriveConnector(BaseConnector):
    name        = "Google Drive"
    description = "List, search and manage files and folders"
    icon        = "📁"

    BASE = "https://www.googleapis.com/drive/v3"

    async def execute(self, task: str, api_key: str) -> str:
        t = task.lower()
        if "upload" in t:
            return self._upload_hint()
        elif "search" in t or "find" in t:
            q = task.split("search")[-1].split("find")[-1].strip()
            return await self._search_files(api_key, q)
        elif "folder" in t:
            return await self._list_files(api_key, query="mimeType='application/vnd.google-apps.folder'")
        elif "recent" in t or "latest" in t:
            return await self._list_files(api_key, order_by="modifiedTime desc")
        else:
            return await self._list_files(api_key)

    async def _list_files(self, token: str, query: str = None, order_by: str = "modifiedTime desc") -> str:
        try:
            headers = {"Authorization": f"Bearer {token}"}
            params = {
                "pageSize": 10,
                "orderBy": order_by,
                "fields": "files(id,name,mimeType,modifiedTime,size,parents)",
            }
            if query:
                params["q"] = query

            r = requests.get(f"{self.BASE}/files", headers=headers, params=params, timeout=15)
            if r.status_code == 401:
                return self._err("Token expired. Please update your Drive token via 🔌 Manage Connectors.")
            if r.status_code != 200:
                return self._err(f"API returned {r.status_code}.")

            files = r.json().get("files", [])
            if not files:
                return "📂 No files found."

            lines = []
            for f in files:
                icon     = _icon(f.get("mimeType", ""))
                name     = f.get("name", "Unknown")[:50]
                modified = f.get("modifiedTime", "")[:10]
                size_b   = f.get("size")
                size_str = f"{int(size_b)//1024} KB" if size_b else ""
                lines.append(f"{icon} `{name}` — {modified} {size_str}".strip())

            return "📂 **Google Drive Files:**\n\n" + "\n".join(lines)

        except Exception as e:
            logger.error(f"GDriveConnector error: {e}")
            return self._err(str(e))

    async def _search_files(self, token: str, keyword: str) -> str:
        query = f"name contains '{keyword}'"
        return await self._list_files(token, query=query)

    def _upload_hint(self) -> str:
        return (
            "📤 **Upload to Google Drive**\n\n"
            "Send me the file you want to upload, then tell me:\n"
            "• Which folder to upload it to\n\n"
            "_Note: File uploads require the Drive API with write scope._"
        )
