"""GitHub Connector — uses GitHub REST API v3 with Personal Access Token."""

import logging
import requests
from connectors.base import BaseConnector

logger = logging.getLogger(__name__)


class GitHubConnector(BaseConnector):
    name        = "GitHub"
    description = "Manage repos, issues, pull requests and code"
    icon        = "🐙"

    BASE    = "https://api.github.com"
    HEADERS = {"Accept": "application/vnd.github.v3+json"}

    def _h(self, token: str) -> dict:
        return {**self.HEADERS, "Authorization": f"token {token}"}

    async def execute(self, task: str, api_key: str) -> str:
        t = task.lower()
        if "create" in t and "repo" in t:
            return self._create_repo_hint(task)
        elif "issue" in t and ("create" in t or "open" in t or "new" in t):
            return self._create_issue_hint()
        elif "issue" in t:
            return await self._list_issues(api_key)
        elif "pull" in t or "pr" in t:
            return await self._list_prs(api_key)
        elif "star" in t:
            return await self._list_starred(api_key)
        elif "gist" in t:
            return await self._list_gists(api_key)
        else:
            return await self._list_repos(api_key)

    async def _list_repos(self, token: str) -> str:
        try:
            r = requests.get(
                f"{self.BASE}/user/repos",
                headers=self._h(token),
                params={"sort": "updated", "per_page": 10},
                timeout=15,
            )
            if r.status_code == 401:
                return self._err("Token invalid or expired. Update via 🔌 Manage Connectors.")
            if r.status_code != 200:
                return self._err(f"API returned {r.status_code}.")

            repos = r.json()
            if not repos:
                return "🐙 You have no repositories yet!"

            lines = []
            for repo in repos[:10]:
                vis    = "🔒" if repo.get("private") else "🌐"
                name   = repo.get("name", "?")
                stars  = repo.get("stargazers_count", 0)
                lang   = repo.get("language") or "—"
                pushed = repo.get("pushed_at", "")[:10]
                lines.append(f"{vis} **{name}** ⭐{stars} · {lang} · {pushed}")

            # Also get user info
            me = requests.get(f"{self.BASE}/user", headers=self._h(token), timeout=10)
            username = me.json().get("login", "?") if me.status_code == 200 else "?"

            return (
                f"🐙 **GitHub — @{username}**\n"
                f"_{len(repos)} repos shown:_\n\n"
                + "\n".join(lines)
            )

        except Exception as e:
            logger.error(f"GitHubConnector error: {e}")
            return self._err(str(e))

    async def _list_issues(self, token: str) -> str:
        try:
            r = requests.get(
                f"{self.BASE}/issues",
                headers=self._h(token),
                params={"state": "open", "per_page": 8},
                timeout=15,
            )
            if r.status_code != 200:
                return self._err(f"Issues API returned {r.status_code}.")

            issues = r.json()
            if not issues:
                return "✅ No open issues across your repos!"

            lines = []
            for issue in issues[:8]:
                num   = issue.get("number", "?")
                title = issue.get("title", "?")[:55]
                repo  = issue.get("repository", {}).get("name", "?")
                lines.append(f"🔴 #{num} **{title}** _({repo})_")

            return f"🐙 **Open Issues ({len(issues)}):**\n\n" + "\n".join(lines)

        except Exception as e:
            return self._err(str(e))

    async def _list_prs(self, token: str) -> str:
        try:
            r = requests.get(
                f"{self.BASE}/search/issues",
                headers=self._h(token),
                params={"q": "is:open is:pr author:@me", "per_page": 8},
                timeout=15,
            )
            if r.status_code != 200:
                return self._err(f"PR API returned {r.status_code}.")

            items = r.json().get("items", [])
            if not items:
                return "✅ No open pull requests!"

            lines = []
            for pr in items[:8]:
                num   = pr.get("number", "?")
                title = pr.get("title", "?")[:55]
                lines.append(f"🟢 #{num} {title}")

            return f"🐙 **Open Pull Requests ({len(items)}):**\n\n" + "\n".join(lines)

        except Exception as e:
            return self._err(str(e))

    async def _list_starred(self, token: str) -> str:
        try:
            r = requests.get(
                f"{self.BASE}/user/starred",
                headers=self._h(token),
                params={"per_page": 8},
                timeout=15,
            )
            if r.status_code != 200:
                return self._err(f"Starred API returned {r.status_code}.")

            repos = r.json()
            if not repos:
                return "⭐ No starred repositories."

            lines = [
                f"⭐ **{r.get('full_name','?')}** — {r.get('description','')[:40]}"
                for r in repos[:8]
            ]
            return "⭐ **Starred Repos:**\n\n" + "\n".join(lines)

        except Exception as e:
            return self._err(str(e))

    async def _list_gists(self, token: str) -> str:
        try:
            r = requests.get(f"{self.BASE}/gists", headers=self._h(token), timeout=15)
            if r.status_code != 200:
                return self._err(f"Gists API returned {r.status_code}.")

            gists = r.json()
            if not gists:
                return "📝 No gists found."

            lines = [
                f"📝 {g.get('description','Untitled')[:50] or 'Untitled'} — {g.get('updated_at','')[:10]}"
                for g in gists[:6]
            ]
            return "📝 **Your Gists:**\n\n" + "\n".join(lines)

        except Exception as e:
            return self._err(str(e))

    def _create_repo_hint(self, task: str) -> str:
        return (
            "🐙 **Create Repository**\n\n"
            "Please tell me:\n"
            "• **Name:** (e.g. `my-awesome-project`)\n"
            "• **Description:** (optional)\n"
            "• **Visibility:** public or private\n\n"
            "_Reply with the details and I'll create it!_"
        )

    def _create_issue_hint(self) -> str:
        return (
            "🐙 **Create Issue**\n\n"
            "Please provide:\n"
            "• **Repo:** owner/repo-name\n"
            "• **Title:** Issue title\n"
            "• **Body:** Description\n\n"
            "_Reply with the details!_"
        )
