"""Gmail Connector — uses Gmail REST API with OAuth Access Token."""

import logging
import requests
from connectors.base import BaseConnector

logger = logging.getLogger(__name__)


class GmailConnector(BaseConnector):
    name        = "Gmail"
    description = "Read, summarize and manage emails"
    icon        = "📧"

    BASE = "https://gmail.googleapis.com/gmail/v1/users/me"

    async def execute(self, task: str, api_key: str) -> str:
        t = task.lower()
        if any(w in t for w in ["send", "write", "compose", "reply"]):
            return self._send_hint(task)
        elif any(w in t for w in ["unread", "unseen"]):
            return await self._list_emails(api_key, query="is:unread", label="Unread")
        elif any(w in t for w in ["latest", "recent", "new", "inbox", "summarize", "summary", "check"]):
            return await self._list_emails(api_key, query="in:inbox", label="Inbox")
        elif "search" in t or "find" in t:
            keyword = task.split("search")[-1].split("find")[-1].strip()
            return await self._list_emails(api_key, query=keyword, label=f"Search: {keyword}")
        else:
            return await self._list_emails(api_key, query="in:inbox", label="Inbox")

    async def _list_emails(self, token: str, query: str = "in:inbox", label: str = "Inbox") -> str:
        try:
            headers = {"Authorization": f"Bearer {token}"}
            r = requests.get(
                f"{self.BASE}/messages",
                headers=headers,
                params={"q": query, "maxResults": 5},
                timeout=15,
            )
            if r.status_code == 401:
                return self._err("Token expired or invalid. Please update your Gmail token via 🔌 Manage Connectors.")
            if r.status_code != 200:
                return self._err(f"API returned {r.status_code}. Check your access token.")

            messages = r.json().get("messages", [])
            if not messages:
                return f"📭 No emails found in **{label}**."

            summaries = []
            for msg in messages[:5]:
                detail = requests.get(
                    f"{self.BASE}/messages/{msg['id']}",
                    headers=headers,
                    params={"format": "metadata", "metadataHeaders": ["Subject", "From", "Date"]},
                    timeout=10,
                )
                if detail.status_code == 200:
                    hdrs = {h["name"]: h["value"] for h in detail.json().get("payload", {}).get("headers", [])}
                    subject = hdrs.get("Subject", "(no subject)")[:60]
                    sender  = hdrs.get("From", "Unknown")[:40]
                    date    = hdrs.get("Date", "")[:16]
                    summaries.append(f"• *{subject}*\n  From: `{sender}`\n  {date}")

            return f"📬 **{label}** — {len(messages)} email(s) found:\n\n" + "\n\n".join(summaries)

        except Exception as e:
            logger.error(f"GmailConnector error: {e}")
            return self._err(str(e))

    def _send_hint(self, task: str) -> str:
        return (
            "📤 **Send Email**\n\n"
            "To send an email, please provide:\n"
            "• **To:** recipient@email.com\n"
            "• **Subject:** Your subject\n"
            "• **Body:** Your message\n\n"
            "_Reply with the details above and I'll send it!_"
        )
