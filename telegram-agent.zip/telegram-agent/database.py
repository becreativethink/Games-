"""
Database — Firebase Realtime Database via REST API
All API keys are encrypted with Fernet before storage.
"""

import os
import logging
import requests
from cryptography.fernet import Fernet
from config import FIREBASE_URL, HF_API_KEY, HF_DEFAULT_MODEL, FREE_MESSAGE_LIMIT

logger = logging.getLogger(__name__)

KEY_FILE = ".encryption_key"


class Database:
    def __init__(self):
        self.base = FIREBASE_URL
        self._init_encryption()
        self._bootstrap_config()

    # ── Encryption ────────────────────────────────────────────────────────────
    def _init_encryption(self):
        if os.path.exists(KEY_FILE):
            with open(KEY_FILE, "rb") as f:
                key = f.read().strip()
        else:
            key = Fernet.generate_key()
            with open(KEY_FILE, "wb") as f:
                f.write(key)
            logger.info("🔐 New encryption key generated.")
        self.fernet = Fernet(key)

    def encrypt(self, text: str) -> str:
        return self.fernet.encrypt(text.encode()).decode()

    def decrypt(self, enc: str) -> str:
        try:
            return self.fernet.decrypt(enc.encode()).decode()
        except Exception:
            return enc  # return as-is if decryption fails (legacy plain text)

    # ── Firebase REST helpers ──────────────────────────────────────────────────
    def _get(self, path: str):
        try:
            r = requests.get(f"{self.base}/{path}.json", timeout=10)
            return r.json() if r.status_code == 200 else None
        except Exception as e:
            logger.error(f"DB GET error ({path}): {e}")
            return None

    def _set(self, path: str, data):
        try:
            r = requests.put(f"{self.base}/{path}.json", json=data, timeout=10)
            return r.status_code == 200
        except Exception as e:
            logger.error(f"DB SET error ({path}): {e}")
            return False

    def _patch(self, path: str, data):
        try:
            r = requests.patch(f"{self.base}/{path}.json", json=data, timeout=10)
            return r.status_code == 200
        except Exception as e:
            logger.error(f"DB PATCH error ({path}): {e}")
            return False

    def _delete(self, path: str):
        try:
            r = requests.delete(f"{self.base}/{path}.json", timeout=10)
            return r.status_code == 200
        except Exception as e:
            logger.error(f"DB DELETE error ({path}): {e}")
            return False

    # ── Config (Global) ───────────────────────────────────────────────────────
    def _bootstrap_config(self):
        """Write default HF API key to Firebase if not already there."""
        existing = self._get("config/hf_api_key")
        if not existing:
            self._set("config/hf_api_key", HF_API_KEY)
            logger.info("✅ Firebase config bootstrapped with default HF API key.")

    def get_hf_api_key(self) -> str:
        key = self._get("config/hf_api_key")
        return key if key else HF_API_KEY

    def set_hf_api_key(self, key: str):
        self._set("config/hf_api_key", key)

    # ── User CRUD ─────────────────────────────────────────────────────────────
    def _default_user(self) -> dict:
        return {
            "message_count":  0,
            "setup_complete": False,
            "ai_config": {
                "provider": "huggingface",
                "model":    HF_DEFAULT_MODEL,
                "api_key":  None,
            },
            "connectors": {},
        }

    def get_user(self, user_id: int) -> dict:
        data = self._get(f"users/{user_id}")
        if not data:
            default = self._default_user()
            self._set(f"users/{user_id}", default)
            return default
        return data

    def reset_user(self, user_id: int):
        self._set(f"users/{user_id}", self._default_user())

    def mark_setup_complete(self, user_id: int):
        self._patch(f"users/{user_id}", {"setup_complete": True})

    def is_setup_complete(self, user_id: int) -> bool:
        return self.get_user(user_id).get("setup_complete", False)

    # ── Message Counter ───────────────────────────────────────────────────────
    def get_message_count(self, user_id: int) -> int:
        return self.get_user(user_id).get("message_count", 0)

    def increment_message_count(self, user_id: int) -> int:
        count = self.get_message_count(user_id) + 1
        self._patch(f"users/{user_id}", {"message_count": count})
        return count

    # ── AI Configuration ──────────────────────────────────────────────────────
    def save_ai_config(self, user_id: int, provider: str, model: str, api_key: str | None = None):
        self._patch(f"users/{user_id}/ai_config", {
            "provider": provider,
            "model":    model,
            "api_key":  self.encrypt(api_key) if api_key else None,
        })

    def get_ai_config(self, user_id: int) -> dict:
        data = self._get(f"users/{user_id}/ai_config") or {}
        if data.get("api_key"):
            data["api_key"] = self.decrypt(data["api_key"])
        return data

    def clear_ai_config(self, user_id: int):
        self._patch(f"users/{user_id}/ai_config", {
            "provider": "huggingface",
            "model":    HF_DEFAULT_MODEL,
            "api_key":  None,
        })

    # ── Connectors ────────────────────────────────────────────────────────────
    def save_connector(self, user_id: int, connector_id: str, api_key: str):
        self._set(f"users/{user_id}/connectors/{connector_id}", {
            "enabled": True,
            "api_key": self.encrypt(api_key),
        })

    def get_connector(self, user_id: int, connector_id: str) -> dict | None:
        data = self._get(f"users/{user_id}/connectors/{connector_id}")
        if data and data.get("api_key"):
            data["api_key"] = self.decrypt(data["api_key"])
        return data

    def get_all_connectors(self, user_id: int) -> dict:
        data = self._get(f"users/{user_id}/connectors") or {}
        result = {}
        for cid, cdata in data.items():
            if cdata and cdata.get("api_key"):
                cdata = dict(cdata)
                cdata["api_key"] = self.decrypt(cdata["api_key"])
            result[cid] = cdata
        return result

    def remove_connector(self, user_id: int, connector_id: str):
        self._delete(f"users/{user_id}/connectors/{connector_id}")

    def get_active_connectors(self, user_id: int) -> list[str]:
        conns = self.get_all_connectors(user_id)
        return [cid for cid, cdata in conns.items() if cdata and cdata.get("enabled")]
