"""
Setup Firebase — run once to initialise the config node.
Updates the HF API key in Firebase so you can change it without redeploying.
"""

import requests
import sys

FIREBASE_URL = "https://eduweb-fcfee-default-rtdb.firebaseio.com"
HF_API_KEY   = "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"


def setup():
    print("🔧 Setting up Firebase config node…")

    # Write HF API key
    r = requests.put(
        f"{FIREBASE_URL}/config/hf_api_key.json",
        json=HF_API_KEY,
    )
    if r.status_code == 200:
        print(f"✅ HF API key written to Firebase: config/hf_api_key")
    else:
        print(f"❌ Failed to write HF key: {r.status_code} {r.text}")
        sys.exit(1)

    # Write free message limit
    r = requests.put(
        f"{FIREBASE_URL}/config/free_message_limit.json",
        json=4,
    )
    if r.status_code == 200:
        print("✅ Free message limit set to 4")
    else:
        print(f"⚠️  Could not write free_message_limit: {r.status_code}")

    print("\n🎉 Firebase setup complete!")
    print("📝 To update the HF API key later, go to Firebase console:")
    print(f"   {FIREBASE_URL}/config/hf_api_key")
    print("\nOr run: python update_hf_key.py <new_key>")


if __name__ == "__main__":
    setup()
