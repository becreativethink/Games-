"""
Task Executor — the brain of the agent.
Routes tasks to the right connector, feeds context to AI, returns results.
"""

import logging
from database  import Database
from ai_engine import AIEngine
from connectors import GmailConnector, GDriveConnector, GitHubConnector
from config import CONNECTORS_CONFIG

logger = logging.getLogger(__name__)

# Intent keyword mapping → connector id
INTENT_MAP = {
    "gmail":   ["email", "gmail", "mail", "inbox", "sent", "unread", "spam", "message"],
    "gdrive":  ["drive", "file", "upload", "download", "folder", "document", "sheet", "gdrive"],
    "github":  ["github", "repo", "repository", "code", "push", "commit", "pull request",
                "pr", "issue", "branch", "gist", "star"],
}


def _detect_intent(task: str) -> str | None:
    tl = task.lower()
    for connector_id, keywords in INTENT_MAP.items():
        if any(kw in tl for kw in keywords):
            return connector_id
    return None


def _tools_description(active_connectors: dict) -> str:
    if not active_connectors:
        return "⚠️ No connectors active (AI-only mode — can reason but cannot access external services)"
    lines = []
    for cid in active_connectors:
        if cid in CONNECTORS_CONFIG:
            info = CONNECTORS_CONFIG[cid]
            lines.append(f"• {info['icon']} **{info['name']}** — {info['description']}")
    return "\n".join(lines)


class TaskExecutor:
    def __init__(self):
        self.db  = Database()
        self.ai  = AIEngine()
        self.connectors = {
            "gmail":  GmailConnector(),
            "gdrive": GDriveConnector(),
            "github": GitHubConnector(),
        }

    async def run(self, user_id: int, task: str) -> dict:
        """
        Returns:
        {
            "status":    "ok" | "free_limit" | "error",
            "ai_output": str,
            "connector_output": str | None,
        }
        """
        # Load user's active connectors
        all_conns    = self.db.get_all_connectors(user_id)
        active_conns = {k: v for k, v in all_conns.items() if v and v.get("enabled")}

        tools_desc = _tools_description(active_conns)

        # Step 1: AI analysis + planning
        ai_output = await self.ai.generate_agent(user_id, task, tools_desc)

        if ai_output == "FREE_LIMIT_REACHED":
            return {"status": "free_limit", "ai_output": None, "connector_output": None}
        if ai_output == "AI_ERROR":
            return {"status": "error", "ai_output": None, "connector_output": None}

        # Step 2: Connector execution
        connector_output = None
        intent = _detect_intent(task)

        if intent and intent in active_conns:
            api_key   = active_conns[intent]["api_key"]
            connector = self.connectors.get(intent)
            if connector:
                try:
                    connector_output = await connector.execute(task, api_key)
                except Exception as e:
                    logger.error(f"Connector {intent} execution error: {e}")
                    connector_output = f"❌ {CONNECTORS_CONFIG[intent]['name']} error: {str(e)}"
        elif intent and intent not in active_conns:
            info = CONNECTORS_CONFIG.get(intent, {})
            connector_output = (
                f"⚠️ **{info.get('icon','')} {info.get('name', intent)} not connected.**\n\n"
                f"Go to 🔌 Manage Connectors to add it."
            )

        return {
            "status":           "ok",
            "ai_output":        ai_output,
            "connector_output": connector_output,
        }
