"""
Update HF API Key in Firebase — no redeploy needed.
Usage:  python update_hf_key.py hf_your_new_key_here
"""

import sys
import requests

FIREBASE_URL = "https://eduweb-fcfee-default-rtdb.firebaseio.com"


def update(new_key: str):
    r = requests.put(f"{FIREBASE_URL}/config/hf_api_key.json", json=new_key)
    if r.status_code == 200:
        print(f"✅ HF API key updated successfully!")
        print(f"   The bot will use the new key on the next request.")
    else:
        print(f"❌ Failed: {r.status_code} {r.text}")


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python update_hf_key.py <new_hf_api_key>")
        sys.exit(1)
    update(sys.argv[1])
